<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h3> Hai </h3>
    <h4>pembayarn dengan detail  pesanan sebagai berikut:<br>
      nama:<?php echo e($pesanan->nama); ?><br>
      total bayar:<?php echo e($pesanan->total_bayar); ?>--(LUNAS)<br>
      telah dikonfirmasi .
    </h4>
    <p> silahkan cetak halaman ini sebagai bukti pesanan/pembayaran anda pada hari H.</p>

<br>
<br>
<p>arahan mengenai titik pertemuan dan dll akan dikabarkan paling lambat  2 hari sebelum hari H</p>
<br><br>
<p>by:Kalseltrip</p>
  </body>
</html>
