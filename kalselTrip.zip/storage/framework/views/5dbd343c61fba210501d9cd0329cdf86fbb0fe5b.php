<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1> Hai Admin </h1>
    <p>Ada pesanan baru dar <?php echo e($request->nama); ?></p>

  </body>
</html>
