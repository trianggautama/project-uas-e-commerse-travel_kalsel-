<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
     <h1>
       Data Destinasi
     </h1>
   </section>

   <!-- Main content -->
   <section class="content">
     <div class="row">
       <div class="col-xs-12">
         <!-- /.box -->

         <div class="box">
           <!-- /.box-header -->
           <div class="box-body">
             <?php if(session('msg')): ?>
    <div class="alert alert-success">

        <p><?php echo e(session('msg')); ?></p>

    </div>
    <?php endif; ?>
             <hr>
             <a   href="/admin/destinasi_tambah" ><i class="fa fa-plus pull-right"> Tambah Destinasi</i></a>
                <br>
                <br>
             <table id="example1" class="table table-bordered table-striped table-resposive">

               <thead>
               <tr>
                 <th>Kode Destinasi</th>
                 <th>Nama Destinasi</th>
                 <th>Alamat</th>
                 <th class="text-center">hapus</th>
                 <th class="text-center">Edit</th>
                 <th class="text-center">Detail</th>
               </tr>
               </thead>
               <tbody>
                 <?php $__currentLoopData = $destinasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                 <td><?php echo e($d->id); ?></td>
                 <td><?php echo e($d->nama_destinasi); ?></td>
                 <td><?php echo e($d->alamat); ?></td>
                   <td class="text-center">
                     <form method="POST" action="/admin/destinasi/<?php echo e($d-> id); ?>/delete">
                   <?php echo e(csrf_field()); ?>

                   <button type="submit" class="btn btn-danger"  onclick="return confirm('Anda yakin akan menghapus destinasi <?php echo $d-> nama_destinasi; ?>?')">
                     <span class="fa fa-trash" aria-hidden="true"></span>
                   </button>
                   <input type="hidden"  name="_method" value="delete"></input>
                   </form>


                     </a>
                   </td>
                   <td class="text-center">
                     <a  href="/admin/<?php echo e($d->id); ?>/destinasi_edit" class="btn btn-primary" title="edit">
                       <i class="fa fa-edit"></i>

                     </a>
                     </td>
                      <td class="text-center">
                     <a href="/admin/detail_jadwal/<?php echo e($d->id); ?>" class="btn btn-info" title="detail">
                       <i class="fa fa-bars"></i>

                     </a>
                   </td>

               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>

             </table>
           </div>
           <!-- /.box-body -->
         </div>
         <!-- /.box -->
       </div>
       <!-- /.col -->
     </div>
     <!-- /.row -->
     <div class="row no-print">
            <div class="col-xs-12">
              <a href="<?php echo e(url('/admin/laporan/destinasi-print')); ?>" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
            </div>
          </div>
          <br>
   </section>
   <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>