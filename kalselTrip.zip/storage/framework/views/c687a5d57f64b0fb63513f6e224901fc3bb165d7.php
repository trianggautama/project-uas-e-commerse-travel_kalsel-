<?php $__env->startSection('content'); ?>


<header class="masthead" id="header">
  <div class="container">
    <div class="intro-text">
      <div class="intro-lead-in" style="font-family: 'Yellowtail', cursive; text-shadow: 2px 2px rgba(0, 0, 0, 0.61)"><?php echo e($destinasi->nama_destinasi); ?></div>
      <div class="intro-heading text-uppercase" style="font-family: 'Handlee', cursive; text-shadow: 2px 2px rgba(0, 0, 0, 0.61);
"><?php echo e($destinasi->alamat); ?></div>
<ul class="list-inline social-buttons">

  <li class="list-inline-item">
    <a href="#destinasi" class=" js-scroll-trigger">
      <i class="fa  fa-play-circle"></i>
    </a>
  </li>
</ul>
    </div>
  </div>
</header>

<div class="container">
<div class="row">
 <div class="col-md-8 col-xs-12" style="margin-bottom:0px;">
   <hr>
   <br>
   <p style="text-align:justify; font-family:'Lora', serif;"><?php echo e($destinasi->keterangan); ?></p>
   <br>
   <h5>Fasilitas:</h5><br>
   <p><?php echo e($destinasi->fasilitas); ?></p>
   <br>
   <br>
      <h3>Jadwal Travel <?php echo e($destinasi->nama_destinasi); ?></h3>
      <hr>

  <!-- <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="row">

   <div class="col-lg-4 col-sm-6 text-center tumbnail">
       <div class="card_jadwal">
           <div class="caption">
             <h3><?php echo e($j->tanggal_berangkat); ?></h4>
               <hr>
             <h4>Rp.<?php echo e($j->harga); ?></h3>
             <h4>kuota:<?php echo e($j->kuota); ?> Orang</h4>


               <a  class=" btn button_c " href="/harga/<?php echo e($j->id); ?>">pesan</a>





           </div>
       </div>
   </div>
 </div>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
-->
<section  id="destinasi">
      <div class="container">
        <div class="row">
          <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-5 col-sm-5 destinasi-item text-center"style="margin-bottom:10px; margin-right:10px;border:1px solid grey;">
            <div class="destinasi-caption">
              <h4><?php echo e($j->tanggal_berangkat); ?></h4>
              <h4>kuota:<?php echo e($j->kuota); ?> Orang</h4>

              <p class="text-muted">Rp.<?php echo e($j->harga); ?>/orang</p>
              <?php
              $cek=$j->kuota;
               ?>
              <?php if($cek>0): ?>
              <a class="btn btn-jadwal" href="pesan/<?php echo e($j->id); ?>" style="background-color:black;color:#fec503;">
                pesan sekarang
              </a>
              <?php else: ?>
              <a class="btn btn-jadwal" href="#" style="background-color:black;color:#fec503;">
                Jadwal Penuh
              </a>
                 <?php endif; ?>
            </div>
          </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <br>
        </div>
      </div>
    </section>
 </div>
 <div class="col-md-4 col-xs-12 text-center">
   <br>
   <br>
   <div class="caption">
     <h3>Bingung Bagaimana Memesan?</h4>
       <a href="/langkah_pemesanan">Langkah Pemesanan</a>
   </div>
   <br>
   <hr>
   <br>
       <div class="caption">
         <h3>blog List</h4>

        <a href="#">pesona indah bukit bukit</a><br>
        <a href="#">pesona indah bukit bukit</a><br>
        <a href="#">pesona indah bukit bukit</a><br>
        <a href="#">pesona indah bukit bukit</a><br>
        <a href="#">pesona indah bukit bukit</a>
       </div>
<br>
<br>
<br>
</div>
 </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>