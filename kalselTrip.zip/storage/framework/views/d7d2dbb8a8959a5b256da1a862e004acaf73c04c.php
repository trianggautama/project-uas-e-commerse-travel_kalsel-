<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1> Pesanan Anda Sudah Diproses </h1>
    <h3>silahkan lakukan pembayaran ke rekening berikut:</h3>
    <p>723543158413746</p><br>
    <p>pembayaran dilakukan paling lambat 48 jam dari waktu pemesanan</p>
  </body>
</html>
