<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header">
              <h1 class="box-title">Detail Pesanan</h1>
            </div>

      <div class="box-body no-padding">
              <table class="table table-striped">
                <tr style="margin-left:15px;">
                  <td>Nama               : <?php echo e($pesanan->nama); ?></td><br>
                </tr>
                <tr>
                  <td>Email              : <?php echo e($pesanan->email); ?></td><br>
                </tr>
                <tr>
                  <td>No Hp              : <?php echo e($pesanan->no_hp); ?></td><br>
                </tr>
                <tr>
                  <td>Tanggal Pemesanan  : <?php echo e($pesanan->created_at); ?></td>
                </tr>
                <tr>
                  <td>Tujuan             : <?php echo e($pesanan->jadwal->destinasi->nama_destinasi); ?></td>
                </tr>
                <tr>
                  <td>tanggal berangkat  : <?php echo e($pesanan->jadwal->tanggal_berangkat); ?></td>
                </tr>
                <tr>
                  <td>Jumlah Pesanan     : <?php echo e($pesanan->jumlah_orang); ?></td>
                </tr>
                <tr>
                  <td>Harga/tiket        : Rp.<?php echo e($pesanan->jadwal->harga); ?>,00</td>
                </tr>
                <tr>
                  <td>Total Bayar  : <?php echo e($pesanan->total_bayar); ?></td>
                </tr>
              </table>

            </div>
            <!-- /.box-body -->

          </div>
          <!-- /.box -->
        </div>

            <form method="POST" action="/admin/pesanan/<?php echo e($pesanan-> id); ?>/delete">
          <?php echo e(csrf_field()); ?>

          <button type="submit" class="btn btn-danger"  onclick="return confirm('Anda yakin akan menghapus destinasi <?php echo $pesanan-> nama; ?>?')" style="margin-left:13px;">
          Hapus data
          </button>
          <input type="hidden"  name="_method" value="delete"></input>
          </form>

        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>