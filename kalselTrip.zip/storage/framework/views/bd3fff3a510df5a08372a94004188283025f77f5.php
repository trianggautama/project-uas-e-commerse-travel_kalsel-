<?php $__env->startSection('content'); ?>
<br>
<br>
<br>
<div class="container">
  <div class="row">
    <div class="col-lg-12">
<h2 class="text-center" style="color: #fed136;">Form Pesanan</h2>
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li> <?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
  </div>

    </div>

<form  method="post"  action="/pesan/<?php echo e($jadwal->id); ?>">
    <?php echo e(csrf_field()); ?>


    <div class="form-group">
      <input type="hidden" name="harga"  class="form-control" value="<?php echo e($jadwal->harga); ?>" />
    </div>
    <div class="form-group">
      <label for="kode_destinasi">Email </label>
      <input type="text" name="email"  class="form-control" value="<?php echo e(old('email')); ?>" />
    </div>
  <div class="form-group">
    <label for="nama_destinasi">Nama </label>
    <input type="text" name="nama"  class="form-control" value="<?php echo e(old('nama')); ?>"/>
  </div>
  <div class="form-group">
    <label for="nama_destinasi">No.hp </label>
    <input type="text" name="no_hp"  class="form-control" value="<?php echo e(old('no_hp')); ?>"/>
  </div>
  <div class="form-group">
    <label for="alamat">jumlah pesanan /orang</label>
    <input type="number" name="jumlah_pesanan" class="form-control" >
  </div>
   <div class="text-right">
     <a href="/" class="btn btn-danger"> Batal</a>
     <input class="btn btn-success" type="submit" name="submit" value="Submit"  onclick="return confirm('Pastikan data anda sudah lengkap dan benar ?')">
     <?php echo e(csrf_field()); ?>


   </div>
 </div>

</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>