<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
     <h1>
       Data Pesanan
     </h1>
   </section>

   <!-- Main content -->
   <section class="content">
     <div class="row">
       <div class="col-xs-12">
         <!-- /.box -->

         <div class="box">
           <!-- /.box-header -->
           <div class="box-body">
             <?php if(session('msg')): ?>
    <div class="alert alert-success">

        <p><?php echo e(session('msg')); ?></p>

    </div>
    <?php endif; ?>
             <hr>

                <br>
             <table id="example1" class="table table-bordered table-striped">

               <thead>
               <tr>
                 <th>Kode Pesanan</th>
                 <th>Nama </th>
                 <th>No.hp </th>
                 <th>Tanggal berangkat</th>
                 <th>Tujuan</th>
                 <th>Jumlah Orang</th>
                 <th>Total bayar</th>
                 <th>Status Bayar</th>
                              </tr>
               </thead>
               <tbody>
                 <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                 <td><?php echo e($p->id); ?></td>
                 <td><a href="/admin/detailpesanan/<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></a></td>
                 <td><?php echo e($p->no_hp); ?></td>
                 <td><?php echo e($p->jadwal->tanggal_berangkat); ?></td>
                 <td><?php echo e($p->jadwal->destinasi->nama_destinasi); ?></td>
                 <td><?php echo e($p->jumlah_orang); ?></td>
                <td>Rp.<?php echo e($p->total_bayar); ?></td>
                   <td class="text-center">
                     <form class="form-horizontal form-label-left" method="post" action="/konfirmasi/<?php echo e($p->id); ?>">
                       <?php echo e(method_field('PUT')); ?>

                       <?php echo e(csrf_field()); ?>

                    <input type="submit" name="submit" class="btn btn-sm btn-success" value="Konfirmasi bayar">
                   </form>
                     </td>

               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>

             </table>
           </div>
           <!-- /.box-body -->
         </div>
         <!-- /.box -->
       </div>
       <!-- /.col -->
     </div>
     <!-- /.row -->
   </section>
   <!-- /.content -->
 </div>
 <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>