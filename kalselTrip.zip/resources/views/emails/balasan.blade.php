<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h3> Hai  kami dari Kalseltrip</h3>
<p>{{$request->content}}</p>
<br><br>
<p>by:Kalseltrip</p>
  </body>
</html>
