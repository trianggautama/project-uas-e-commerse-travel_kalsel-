@extends('layouts.app2')

@section('content')
<br>
<br>
<br>

<div class="container text-center">
  <img src="/img/check.png" alt="#" >
  <h3>Pesanan Telah Diproses</h3>
  <h5>silahkan cek email anda untuk langkah berikutnya </h5>
  <br>
  <a href="/" class="btn btn-warning" style="color:white;">Back</a>
</div>
<br>
<br>
<br>
@endsection
